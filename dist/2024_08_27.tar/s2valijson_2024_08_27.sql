CREATE FUNCTION s2valijson_2024_08_27_validate_json_inner(
    input LONGTEXT NOT NULL,
    sch LONGTEXT NOT NULL)
    RETURNS TINYINT(1) NOT NULL
    AS WASM
    FROM LOCAL INFILE 'validate_json.wasm'
    USING EXPORT 'ValidateJSON';

DELIMITER //
CREATE FUNCTION s2valijson_2024_08_27_validate_json(
    input LONGTEXT NULL,
    sch LONGTEXT NULL)
RETURNS TINYINT(1) AS
BEGIN
    IF ISNULL(input) OR ISNULL(sch) THEN
        RETURN NULL;
    END IF;
    RETURN s2valijson_2024_08_27_validate_json_inner(input, sch);
END //
DELIMITER ;

CREATE FUNCTION s2valijson_2024_08_27_validate_json_errors_inner(
    input LONGTEXT NOT NULL,
    sch LONGTEXT NOT NULL)
    RETURNS RECORD(success TINYINT(1) NOT NULL, errors LONGTEXT NOT NULL)
    AS WASM
    FROM LOCAL INFILE 'validate_json_errors.wasm'
    USING EXPORT 'ValidateJSONErrors';

DELIMITER //
CREATE FUNCTION s2valijson_2024_08_27_validate_json_errors(
    input LONGTEXT NULL,
    sch LONGTEXT NULL)
RETURNS LONGTEXT AS
DECLARE
    result RECORD(success TINYINT(1) NOT NULL, errors LONGTEXT NOT NULL);
BEGIN
    IF ISNULL(input) OR ISNULL(sch) THEN
        RETURN NULL;
    END IF;
    result = s2valijson_2024_08_27_validate_json_errors_inner(input, sch);
    IF result.success = 1 THEN
        RETURN NULL;
    ELSE
        RETURN result.errors;
    END IF;
END //
DELIMITER ;

DELIMITER //
CREATE FUNCTION s2valijson_2024_08_27_validate_json_raise(
    input LONGTEXT NULL,
    sch LONGTEXT NULL)
RETURNS LONGTEXT AS
DECLARE
    result RECORD(success TINYINT(1) NOT NULL, errors LONGTEXT NOT NULL);
BEGIN
    IF ISNULL(input) OR ISNULL(sch) THEN
        RETURN NULL;
    END IF;
    result = s2valijson_2024_08_27_validate_json_errors_inner(input, sch);
    IF result.success = 1 THEN
        RETURN input;
    ELSE
        RAISE USER_EXCEPTION(result.errors);
    END IF;
END //
DELIMITER ;

